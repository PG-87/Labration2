package Network;

import java.io.*;
import java.net.Socket;

public class Client {
    public static void connectTo() {
        try( Socket socket = new Socket("82.196.127.10", 8000) ) {
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);
            writer.println("Hello World");
            writer.flush();

            InputStream input = socket.getInputStream();
            //InputStreamReader reader = new InputStreamReader(input);
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
//            while (true) {
//
//                    String line = reader.readLine();    // reads a line of text
//                    System.out.println(line);
//            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
