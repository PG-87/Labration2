package StackOperations;

public interface Change {
    void undo();

}
