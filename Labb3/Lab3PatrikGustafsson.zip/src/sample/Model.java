package sample;

import StackOperations.Change;
import javafx.beans.Observable;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.util.Callback;
import sample.shapes.Shape;

import java.util.Stack;

public class Model {

    public static Stack<Change> undoStack = new Stack();

    private ObservableList<Shape> shapeList = FXCollections.observableArrayList(new Callback<Shape, Observable[]>() {
        @Override
        public Observable[] call(sample.shapes.Shape param) {
            return new Observable[]{
                    param.idProperty(),
                    param.paintProperty(),
                    param.sizeProperty()
            };
        }
    });

    public void setShapeList(ObservableList<Shape> shapeList) {
        this.shapeList = shapeList;
    }
    public ObservableList<Shape> getShapeList() {
        return shapeList;
    }
    public void addShapes(Shape shape) {
        shapeList.add(shape);
    }

    private IntegerProperty size = new SimpleIntegerProperty();
    public int getSize() {
        return size.get();
    }
    public IntegerProperty sizeProperty() {
        return size;
    }
    public void setSize(int size) {
        this.size.set(size);
    }
}
